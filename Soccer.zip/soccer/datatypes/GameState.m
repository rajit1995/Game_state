classdef GameState < Simulink.IntEnumType
    
    
    enumeration
        InPlay(1)
        OutOfPlay(2)
        GoalScored(3)
    end
    
end

%%
state = GameState.Inplay;